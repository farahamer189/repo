<div class="bg-dark  p-2 text-light text-center footer">
<style>
        html {
            height: 100%;
        }

        body {
            min-height: 100%;
            display: flex;
            flex-direction: column;
        }

        .container {
            flex: 1;
        }
    </style>
                        <P> All rights @ Designed by MIU University-2023</p>

        
                    </div>