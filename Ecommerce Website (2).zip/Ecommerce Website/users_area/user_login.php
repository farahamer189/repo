<?php
include('../includes/connect.php');
include('../functions/common_function.php');
@session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Login</title>

    <!-- Bootstrap CSS link -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" 
          rel="stylesheet" 
          integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" 
          crossorigin="anonymous">
    <style>
        body {
            background-color: #f8f9fa;
        }

        .login-container {
            max-width: 400px;
            margin: auto;
            margin-top: 5%;
        }

        .login-form {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .login-title {
            text-align: center;
            margin-bottom: 20px;
        }

        .login-btn {
            background-color: #343a40;
            color: #ffffff;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-lg-4 col-md-6 col-sm-8 col-10 mt-5">
            <!-- <img src="images/back.jpg" class="img-fluid mb-3" style="max-height:100px;"> -->

                <form action="" method="post" class="login-form">
                    <h2 class="login-title">Login</h2>
                    <div class="mb-3">
                        <label for="user_username" class="form-label">Username</label>
                        <input type="text" id="user_username" class="form-control"
                            placeholder="Enter your username" autocomplete="off"
                            required="required" name="user_username">
                    </div>

                    <div class="mb-3">
                        <label for="user_password" class="form-label">Password</label>
                        <input type="password" id="user_password" class="form-control"
                            placeholder="Enter your password" autocomplete="off"
                            required="required" name="user_password">
                    </div>

                    <div class="mb-3 form-check">
                        <input type="checkbox" class="form-check-input" id="rememberMe">
                        <label class="form-check-label" for="rememberMe">Remember me</label>
                    </div>

                    <button type="submit" class="btn btn-dark w-100 login-btn" name="user_login">Login</button>

                    <p class="small mt-3 text-center">
                        Don't have an account? <a href="user_registration.php" class="text-blue">Register</a>
                    </p>
                </form>
            </div>
        </div>
    </div>
</body>
</html>



<?php

if (isset($_POST['user_login'])){

    $user_username=$_POST['user_username'];
    $user_password=$_POST['user_password'];
 //echo $user_password; 

 $select_query="Select * from `user_table` where username='$user_username'";
$result=mysqli_query($con,$select_query);
$row_count=mysqli_num_rows($result);
$row_data=mysqli_fetch_assoc($result);
$user_ip=getIPAddress();


//cart item
$select_query_cart="select * from `cart_details` where 
ip_address='$user_ip'";
$select_cart=mysqli_query($con,$select_query_cart);
$row_count_cart=mysqli_num_rows($select_cart);
if ($row_count>0){
    $_SESSION['username']=$user_username;
    if (password_verify($user_password,$row_data['user_password'])){
        
if ($row_count==1 and $row_count_cart==0){
    $_SESSION['username']=$user_username;
         echo "<script>alert('Login succesful')</script>";
     echo "<script>window.open('profile.php','_self')</script>";
}else{
    $_SESSION['username']=$user_username;
    echo "<script>alert('Login succesful')</script>";
    echo "<script>window.open('payment.php','_self')</script>";

}
}else{
    echo "<script>alert('Wrong Username or Password')</script>";
    }


}else{
    echo "<script>alert('Wrong Username or Password')</script>";



}
}

?>