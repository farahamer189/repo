<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>

    <!-- Bootstrap CSS link -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" 
            rel="stylesheet" 
            integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" 
            crossorigin="anonymous">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .container {
            max-width: 600px;
            margin: 50px auto;
            background-color: #ffffff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }

        h3 {
            text-align: center;
            color: #343a40;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            font-weight: bold;
            color: #495057;
        }

        .btn-black {
            background-color: #343a40;
            color: #ffffff;
        }
    </style>
</head>
<body>
    <div class="container">
        <h3>Contact Us</h3>
        <form method="POST" action="">
            <div class="form-group">
                <label for="user_name">Name</label>
                <input type="text" name="user_name" id="user_name" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="user_email">Email</label>
                <input type="email" name="user_email" id="user_email" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="user_phone_number">Phone Number</label>
                <input type="tel" name="user_phone_number" id="user_phone_number" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="user_message">Message</label>
                <textarea name="user_message" id="user_message" class="form-control" rows="5" required></textarea>
            </div>

            <div class="form-group">
                <button type="submit" name="contact" class="btn btn-black">Submit Feedback</button>
            </div>
        </form>
    </div>
</body>
</html>

<?php
include('../includes/connect.php');
session_start();

if (isset($_POST['contact'])) {
    $user_name = $_POST['user_name'];
    $user_email = $_POST['user_email'];
    $user_phone_number = $_POST['user_phone_number'];
    $user_message = $_POST['user_message'];

    // select query
    $select_query = "SELECT * FROM `user_feedback` WHERE user_name='$user_name' OR user_email='$user_email'";
    $result = mysqli_query($con, $select_query);
    $rows_count = mysqli_num_rows($result);

    if ($rows_count > 0) {
        echo "<script>alert('This Message already submitted before')</script>";
    } else {
        // insert query
        $insert_query = "INSERT INTO `user_feedback` (user_name, user_email, user_phone_number, user_message) 
                        VALUES ('$user_name', '$user_email', '$user_phone_number', '$user_message')";
        $sql_execute = mysqli_query($con, $insert_query);

        if ($sql_execute) {
            echo "<script>alert('Message submitted successfully')</script>";
        } else {
            echo "<script>alert('Submission failed')</script>";
        }
    }
}
?>
