<h3 class="text-center text-dark">All Orders</h3>
<table class="table table-bordered mt-5">
    <thead class="bg-info">

        <tr>
            <th>Sl no</th>
            <th>Amount Due</th>
            <th>Invoice number</th>
            <th>Total Products</th>
            <th>Order Date</th>
            <th>Status</th>
            <th>Delete</th>
        </tr>
    </thead>
    <tbody class='bg-secondary text-light'>
        <?php
        $select_order= "SELECT * FROM `user_orders`";
        $result = mysqli_query($con, $select_order);
        $number = 0;

        while ($row = mysqli_fetch_assoc($result)) {
            $order_id = $row['order_id'];
            $user_id = $row['user_id'];
            $amount_due = $row['amount_due'];
            $invoice_number = $row['invoice_number'];
            $total_products = $row['total_products'];
            $order_date = $row['order_date'];
            $order_status = $row['order_status'];
            $number++;
        ?>
            <tr class="text-center">
                <td><?php echo $number; ?></td>
                <td><?php echo $amount_due ?></td>
                <td><?php echo $invoice_number ?></td>
                <td><?php echo $total_products ?></td>
                <td><?php echo $order_date ?></td>
                <td><?php echo $order_status ?></td>
                    
                
                <td><a href='index.php?list_orders=<?php echo $order_id ?>' 
                type="button"class="text-dark"
                ><i class='fa-solid 
                fa-trash' style='color:black;'></i></a></td>
            </tr>
        <?php
        }?>
    </tbody>
</table>
<?php

if(isset($_GET['list_orders'])){
$delete_id=$_GET['list_orders'];

$list_orders="Delete from `user_orders` where order_id=$delete_id";
$result_order=mysqli_query($con,$list_orders);
if($result_order){

    echo "<script>alert('order deleted successfully')</script>";
    echo "<script>window.open('./index.php?list_orders','_self')</script>";
}
}

?>