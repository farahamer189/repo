<?php
if (isset($_GET['edit_products'])) {
    $edit_id = $_GET['edit_products'];
    $get_data = "SELECT * FROM products WHERE product_id='$edit_id'";
    $result = mysqli_query($con, $get_data);
    $row = mysqli_fetch_assoc($result);
    $product_title = $row['product_title'];
    $product_description = $row['product_description'];
    $category_id = $row['category_id'];
    $brand_id = $row['brand_id'];
    $product_image = $row['product_image'];
    $product_price = $row['product_price'];
}

if (isset($_POST['edit_product'])) {
    // Retrieve form data
    $new_product_title = $_POST['product_title'];
    $new_product_description = $_POST['product_desc'];
    $new_category_id = $_POST['product_category'];
    $new_brand_id = $_POST['product_brands'];
    $new_product_image = $_FILES['product_image']['name'];
    $new_product_price = $_POST['product_price'];

    // Update the database
    $update_query = "UPDATE products SET 
        product_title='$new_product_title',
        product_description='$new_product_description',
        category_id='$new_category_id',
        brand_id='$new_brand_id',
        product_image='$new_product_image',
        product_price='$new_product_price'
        WHERE product_id='$edit_id'";

    $update_result = mysqli_query($con, $update_query);

    // Handle file upload if a new image is selected
    if ($new_product_image) {
        $target_dir = "./product_images/";
        $target_file = $target_dir . basename($_FILES['product_image']['name']);
        move_uploaded_file($_FILES['product_image']['tmp_name'], $target_file);
    }
// Display alert if update is successful
if ($update_result) {
    echo "<script>alert('Product edited successfully')</script>";
}

    
}
?>

<div class="container mt-5">
<h1 class="text-center">Edit products</h1>
<form action="" method="post" enctype="multipart/form-data">
    <div class="form-outline w-50 m-auto mb-4">
        <label for="product_title" class="form-label">product Title</label>
        <input type="text" id="product_title" 
        value="<?php echo $product_title ?>"
        name="product_title" class="form-control"required="required">
</div>

<div class="form-outline w-50 m-auto mb-4">
        <label for="product_desc" class="form-label">Product Description</label>
        <input type="text" id="product_desc" name="product_desc"
            value="<?php echo $product_description ?>" class="form-control"
        required="required">
</div>

<div class="form-outline w-50 m-auto mb-4">
<label for="product_category" class="form-label">Product Category</label>
        <select name="product_category"
value="<?php echo $category_title?>"
class="form-select">
<?php

$select_category_all="Select * from categories";
$result_category_all=mysqli_query($con,$select_category_all);
while($row_category_all=mysqli_fetch_assoc($result_category_all)){
$category_title=$row_category_all['category_title'];
$category_id=$row_category_all['category_id'];
echo" <option value='$category_id'>$category_title</option>";
};


?>
</select>
        </div>
        <div class="form-outline w-50 m-auto mb-4">
        <label for="product_brand" class="form-label">Product Brand</label>
    <select name="product_brands" class="form-select">

    <?php
// Assuming $con is your database connection, make sure it's defined before using it.

$select_brand_all = "SELECT * FROM brands";
$result_brand_all = mysqli_query($con, $select_brand_all);

if (!$result_brand_all) {
    die("Query failed: " . mysqli_error($con));
}

while ($row_brand_all = mysqli_fetch_assoc($result_brand_all)) {
    $brand_title = $row_brand_all['brand_title'];
    $brand_id = $row_brand_all['brand_id'];
    echo "Brand ID: $brand_id, Brand Title: $brand_title<br>";
    echo "<option value='$brand_id'>$brand_title</option>";
}
?>




    </select>
</div>
<div class="form-outline w-50 m-auto mb-4">
        <label for="product_image" class="form-label">Product Image</label>
        <div class="d-flex">
        <input type="file" id="product_image" name="product_image"class="form-control w-90 m-auto"
        required="required">
<img src="./product_images/<?php echo $product_image?>" alt="" class="product_img">
        </div>
        </div>
        <div class="form-outline w-50 m-auto mb-4">
        <label for="product_price" class="form-label">product price</label>
        <input type="text" id="product_price" value="<?php echo $product_price?>" name="product_price"class="form-control"
        required="required">
</div>
<div class="w-50 m-auto">
<input type="submit"name="edit_product" value="Update product"
class="btn btn-info px-3 mb-3 m-3">
</div>
</form>
</div>