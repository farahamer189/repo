
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Registration</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" 
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" 
        crossorigin="anonymous">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" 
        integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" 
        crossorigin="anonymous" 
        referrerpolicy="no-referrer" />

    <style>
        body {
            overflow: hidden;
            background-color: #f8f9fa;
        }

        .container-fluid {
            padding: 3rem;
        }

        h2 {
            text-align: center;
            margin-bottom: 2rem;
            color: #343a40;
        }

        .img-fluid {
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        form {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .form-label1 {
            color: #495057;
        }

        .form-control {
            border-radius: 4px;
        }

        input[type="submit"] {
            background-color: #0d6efd;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #0b5ed7;
        }

        .link-danger {
            color: #dc3545;
        }

        .link-danger:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <h2 class="mb-5">Admin Registration</h2>
        <div class="row d-flex justify-content-center">
            <div class="col-lg-6 col-xl-5">
                <img src="../images/adminreg.jpg" alt="Admin Registration" class="img-fluid">
            </div>
            <div class="col-lg-6 col-xl-5">
                <form action="" method="post">
                    <div class="mb-4">
                        <label for="username" class="form-label1">Username</label>
                        <input type="text" id="username" name="username" placeholder="Enter your username" required class="form-control">
                    </div>
                    <div class="mb-4">
                        <label for="email" class="form-label1">Email</label>
                        <input type="email" id="email" name="email" placeholder="Enter your email" required class="form-control">
                    </div>
                    <div class="mb-4">
                        <label for="password" class="form-label1">Password</label>
                        <input type="password" id="password" name="password" placeholder="Enter your password" required class="form-control">
                    </div>
                    <div class="mb-4">
                        <label for="confirmPassword" class="form-label1">Confirm Password</label>
                        <input type="password" id="confirmPassword" name="confirmPassword" placeholder="Confirm your password" required class="form-control">
                    </div>
                    <div>
                        <input type="submit" class="bg-info py-2 px-4 border-0" name="admin_registeration" value="Register">
                        <p class="small fw-bold mt-2 pt-1">Already have an account? <a href="admin_login.php" class="link-danger">Login</a></p>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" 
            integrity="sha384-h8h3W/BTHI1L3I6EnY2JsKFE9suBjBP9zXStQssu3lFqefQbThXj47HCK9oAVT50" 
            crossorigin="anonymous"></script>
</body>
</html>
<?php
include('../includes/connect.php');
include('../functions/common_function.php');

session_start();

if (isset($_POST['admin_registeration'])) {
    $username = $_POST['username'];
    $admin_email = $_POST['email'];
    $admin_password = $_POST['password'];
    $hash_password = password_hash($admin_password, PASSWORD_DEFAULT);
    $conf_admin_password = $_POST['confirmPassword'];

    // select query
    $select_query = "SELECT * FROM `admin_table` WHERE admin_name='$username' OR admin_email='$admin_email'";
    $result = mysqli_query($con, $select_query);
    $rows_count = mysqli_num_rows($result);

    if ($rows_count > 0) {
        echo "<script>alert('Admin name or Email already exist')</script>";
    } elseif ($admin_password != $conf_admin_password) {
        echo "<script>alert('Password is not match')</script>";
    } else {
        // insert query
        $insert_query = "INSERT INTO `admin_table` (admin_name, admin_email, admin_password) 
                        VALUES('$username', '$admin_email', '$hash_password')";
        $sql_execute = mysqli_query($con, $insert_query);

        if ($sql_execute) {
            echo "<script>alert('Registration successful')</script>";
        } else {
            echo "<script>alert('Registration failed')</script>";
        }
    }
}
?>
