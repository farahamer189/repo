<h3 class="text-center text-dark">All Payments</h3>
<table class="table table-bordered mt-5">
    <thead class="bg-info">

        <tr>
            <th>Sl no</th>
            <th>Invoice number</th>
            <th>Amount</th>
            <th>Payment mode</th>
            <th>Order Date</th>
            <th>Delete</th>
        </tr>
    </thead>
    <tbody class='bg-secondary text-light'>
        <?php
        $select_payment= "SELECT * FROM user_payment";
        $result = mysqli_query($con, $select_payment);
        $number = 0;

        while ($row_data= mysqli_fetch_assoc($result)) {
            $order_id = $row_data['order_id'];
            $payment_id=$row_data['payment_id'];
            $amount=$row_data['amount'];
            $invoice_number=$row_data['invoice_number'];;
            $payment_mode=$row_data['payment_mode'];
            $date=$row_data['date'];
            $number++;
        ?>
            <tr class="text-center">
                <td><?php echo $number; ?></td>
                <td><?php echo $amount ?></td>
                <td><?php echo $invoice_number ?></td>
                <td><?php echo $payment_mode ?></td>
                <td><?php echo $date ?></td>
                
                    
                
                <td><a href='index.php?list_payments=<?php echo $payment_id ?>' 
                type="button"class="text-dark"
                ><i class='fa-solid 
                fa-trash' style='color:black;'></i></a></td>
            </tr>
        <?php
        }?>
    </tbody>
</table>
<?php

if(isset($_GET['list_payments'])){
$delete_id=$_GET['list_payments'];

$list_payments="Delete from `user_payment` where payment_id=$delete_id";
$result_payment=mysqli_query($con,$list_payments);
if($result_payment){

    echo "<script>alert('payment deleted successfully')</script>";
    echo "<script>window.open('./index.php?list_payments','_self')</script>";
}
}

?>