<h3 class="text-center text-black">All brands</h3>
<table class="table table-bordered mt-5">
<thead class="bg-info">
<tr class="text-center">
                <th>Slno</th>
                <th>brand <title></title></th>
                <th>Edit</th>
                <th>Delete</th>


    </tr>
</thead>
<tbody class="bg-secondary text-black">
<?php
        $select_brand= "Select * from  `brands`";
        $result = mysqli_query($con, $select_brand);
        $number = 0;
        while ($row = mysqli_fetch_assoc($result)) {
            $brand_id=$row['brand_id'];
            $brand_title=$row['brand_title'];
            $number++; 
        ?>
<tr class="text-center">
        <td><?php  echo $brand_id;?></td>
        <td><?php  echo $brand_title;?></td>
        <td><a href='index.php?edit_brands=<?php echo $brand_id ?>' class='text-light'><i class='fa-solid 
                fa-pen-to-square' style='color:black;'></i></a></td>

                <td><a href='index.php?view_brands=<?php echo $brand_id ?>' 
                type="button" class="text-light" 
                ><i class='fa-solid 
                fa-trash' style='color:black;'></i></a></td>
    </tr>
    <?php
            } ?>
</tbody>
</table>

<!-- delete brandsfunction -->
<?php

if(isset($_GET['view_brands'])){
    $view_brands=$_GET['view_brands'];


    $delete_query="Delete from `brands` where 
    brand_id=$view_brands";
    $result=mysqli_query($con,$delete_query);
    if($result){
        echo "<script>alert('Brand has been Deleted successfully')</script>";
        echo "<script>window.open('./index.php?view_brands','_self')</script>";
    }
}


?> 