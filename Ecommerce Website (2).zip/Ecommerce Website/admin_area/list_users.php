<h3 class="text-center text-dark">List of Users</h3>
<table class="table table-bordered mt-5">
    <thead class="bg-info">

        <tr>
            <th>Sl no</th>
            <th>UserName</th>
            <th>User Email</th>
            <th>User Image</th>
            <th>User Address</th>
            <th>User Mobile</th>
            <th>Delete</th>
        </tr>
    </thead>
    <tbody class='bg-secondary text-light'>
        <?php
        $select_user= "SELECT * FROM user_table";
        $result = mysqli_query($con, $select_user);
        $number = 0;

        while ($row_data= mysqli_fetch_assoc($result)) {
            $user_id = $row_data['user_id'];
            $username=$row_data['username'];
            $user_email=$row_data['user_email'];
            $user_image=$row_data['user_image'];
            $user_address=$row_data['user_address'];
            $user_mobile=$row_data['user_mobile'];
            $number++;
        ?>
            <tr class="text-center">
                <td><?php echo  $user_id; ?></td>
                <td><?php echo  $username; ?></td>
                <td><?php echo $user_email ?></td>
                <td><img src='../users_area/user_images/<?php echo $user_image; ?>'class='user_img '/></td>
                <td><?php echo  $user_address; ?></td>
                <td><?php echo $user_mobile ?></td>
                
                
                    
                
                <td><a href='index.php?list_users=<?php echo $user_id ?>' 
                type="button"class="text-dark"
                ><i class='fa-solid 
                fa-trash' style='color:black;'></i></a></td>
            </tr>
        <?php
        }?>
    </tbody>
</table>

<?php

if(isset($_GET['list_users'])){
    $delete_id = $_GET['list_users'];


    $list_users_query = "DELETE FROM user_table WHERE user_id = $delete_id";
    $result_user = mysqli_query($con, $list_users_query);

    if($result_user){
        echo "<script>alert('User deleted successfully')</script>";
        echo "<script>window.open('./index.php?list_users','_self')</script>";
    }
}

?>
