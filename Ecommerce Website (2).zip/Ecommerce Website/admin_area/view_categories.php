<h3 class="text-center text-black">All categories</h3>
<table class="table table-bordered mt-5">
<thead class="bg-info">
<tr class="text-center">
                <th>Slno</th>
                <th>Category <title></title></th>
                <th>Edit</th>
                <th>Delete</th>


        </tr>
</thead>
<tbody class="bg-secondary text-black">
<?php
        $select_cat= "Select * from  `categories`";
        $result = mysqli_query($con, $select_cat);
        $number = 0;
        while ($row = mysqli_fetch_assoc($result)) {
            $category_id=$row['category_id'];
            $category_title=$row['category_title'];
            $number++; 
        ?>
<tr class="text-center">
        <td><?php  echo $number;?></td>
        <td><?php  echo $category_title;?></td>
        <td><a href='index.php?edit_category=<?php echo $category_id  ?>' class='text-light'><i class='fa-solid 
                fa-pen-to-square' style='color:black;'></i></a></td>

                <td><a href='index.php?view_categories=<?php echo $category_id  ?>' 
                type ="button" class="text-light"
               ><i class='fa-solid 
                fa-trash' style='color:black;'></i></a></td>
    </tr>
    <?php
            } ?>
</tbody>
</table>

<!-- delete category func -->
<?php

if(isset($_GET['view_categories'])){
$view_categories=$_GET['view_categories'];
    $delete_query="Delete from `categories` where 
    category_id=$view_categories";
    $result=mysqli_query($con,$delete_query);
    if($result){
        echo "<script>alert('Category has been Deleted successfully')</script>";
        echo "<script>window.open('./index.php?view_categories','_self')</script>";
    }
}


?> 